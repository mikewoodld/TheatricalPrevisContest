https://www.capture.se/Blog/Post/5771/An-update-on-macOS-and-Intel-GPUs
https://www.capture.se/Blog/Post/5444/Future-macOS-GPU-compatibility

This is a backsaved version of the presentation file for Macs affected by the issues above.
